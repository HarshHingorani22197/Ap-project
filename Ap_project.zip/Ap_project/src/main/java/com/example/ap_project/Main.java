package com.example.ap_project;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.Objects;

public class Main extends Application {
    public static void main(String[] args) {
        launch();
    }
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/scene1.fxml")));
        stage.setTitle("Stick Hero");
        Scene scene = new Scene(root);
        stage.setScene(scene);
        Image icon = new Image("/sh2.png");
        stage.getIcons().add(icon);
        stage.setResizable(false);
        stage.show();
    }
}